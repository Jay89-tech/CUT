package com.example.health_plus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
