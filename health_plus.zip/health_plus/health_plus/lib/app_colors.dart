import 'package:flutter/material.dart';

class AppColors {
  Color blueDark = const Color(0xFF062CF1);
  Color lightGreen = const Color(0xFF04ECD3);
  Color red = const Color(0xFFDC272E);
  Color green = const Color.fromARGB(255, 94, 255, 0);
}
