﻿using Microsoft.AspNetCore.Mvc;
using S2P1.Models;
using System.Collections.Generic;
using System.Linq;

namespace S2P1.Controllers
{
    public class WaterBottleController : Controller
    {
        private IEnumerable<WaterBottle> GetWaterBottles()
        {
            var manufacturer1 = new Manufacturer
            {
                ManufacturerID = "M001",
                Name = "Acme Water Bottles",
                Address = "123 Water Street"
            };

            var manufacturer2 = new Manufacturer
            {
                ManufacturerID = "M002",
                Name = "Water Bottles Inc.",
                Address = "5678 Oak Street"
            };

            var waterBottles = new List<WaterBottle>
            {
                new WaterBottle { BarCode = "1234567890", Volume = 1, Color = "Blue", Manufacturer = manufacturer1 },
                new WaterBottle { BarCode = "0987654321", Volume = 2, Color = "Red", Manufacturer = manufacturer1 },
                new WaterBottle { BarCode = "1122334455", Volume = 3, Color = "Green", Manufacturer = manufacturer1 },
                new WaterBottle { BarCode = "5566778899", Volume = 4, Color = "Yellow", Manufacturer = manufacturer2 },
                new WaterBottle { BarCode = "6677889900", Volume = 5, Color = "Black", Manufacturer = manufacturer2 },
                new WaterBottle { BarCode = "4455667788", Volume = 1, Color = "White", Manufacturer = manufacturer1 },
                new WaterBottle { BarCode = "2233445566", Volume = 2, Color = "Purple", Manufacturer = manufacturer1 },
                new WaterBottle { BarCode = "3344556677", Volume = 3, Color = "Orange", Manufacturer = manufacturer2 },
                new WaterBottle { BarCode = "7788990011", Volume = 4, Color = "Pink", Manufacturer = manufacturer2 },
                new WaterBottle { BarCode = "9900112233", Volume = 5, Color = "Gray", Manufacturer = manufacturer2 },
            };

            return waterBottles;
        }

        public IActionResult Index()
        {
            var waterBottles = GetWaterBottles();
            return View(waterBottles);
        }

        public IActionResult Details(string barCode)
        {
            var waterBottle = GetWaterBottles().FirstOrDefault(w => w.BarCode == barCode);
            if (waterBottle == null)
            {
                return NotFound();
            }
            return View(waterBottle);
        }
    }
}
