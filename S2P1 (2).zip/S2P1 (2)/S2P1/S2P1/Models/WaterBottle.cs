﻿using System.ComponentModel.DataAnnotations;

namespace S2P1.Models
{
    public class WaterBottle
    {
        [Required(ErrorMessage = "The Bar code is required")]
        [RegularExpression("^[0-9]{10}$", ErrorMessage = "The bar code must have a length of 10 and only digits are allowed.")]
        public string BarCode { get; set; }

        [Required(ErrorMessage = "The volume is required")]
        [Range(1, 5, ErrorMessage = "Valid values are 1, 2, 3, 4, and 5.")]
        public int Volume { get; set; }

        [Required(ErrorMessage = "The color is required")]
        public string Color { get; set; }

        [Required(ErrorMessage = "The Manufacturer is required")]
        public Manufacturer Manufacturer { get; set; }
    }
}
