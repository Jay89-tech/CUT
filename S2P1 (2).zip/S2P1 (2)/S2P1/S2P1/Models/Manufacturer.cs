﻿using System.ComponentModel.DataAnnotations;

namespace S2P1.Models
{
    public class Manufacturer
    {
        [Required(ErrorMessage = "The Manufacturer ID is required")]
        [StringLength(10, MinimumLength = 5, ErrorMessage = "The Manufacturer ID must be between 5 and 10 characters long.")]
        public string ManufacturerID { get; set; }

        [Required(ErrorMessage = "The manufacturer name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "The manufacturer address is required")]
        public string Address { get; set; }
    }
}
